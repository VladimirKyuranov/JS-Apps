const commonPartials = (function () {
    return {
        header: "./views/common/header.hbs",
        footer: "./views/common/footer.hbs"
    };
}());